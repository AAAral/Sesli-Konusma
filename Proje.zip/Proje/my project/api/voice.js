export default function handler(req, res) {
    if (req.method === 'POST') {
        const voiceData = req.body; 
        console.log('Ses verisi alındı:', voiceData);
        res.status(200).json({ message: 'Ses verisi alındı' });
    } else {
        res.status(405).end(); // Yalnızca POST istekleri kabul edilir
    }
}
