const startBtn = document.getElementById("start-btn");

startBtn.addEventListener("click", () => {
    // Socket.io ile bağlantı kur
    const socket = io();

    // Kullanıcının mikrofonuna erişim isteği
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
            const mediaRecorder = new MediaRecorder(stream);
            mediaRecorder.start();

            mediaRecorder.ondataavailable = (event) => {
                // Mikrofon verilerini sunucuya gönder
                socket.emit('voice', event.data);
            };
        })
        .catch(err => {
            console.error("Mikrofona erişim reddedildi", err);
        });
});
